#include "xaxidma.h"
#include "xparameters.h"
#include "xil_exception.h"
#include "xscugic.h"

/************************** Constant Definitions *****************************/

#define DMA_DEV_ID              XPAR_AXIDMA_0_DEVICE_ID
#define RX_INTR_ID              XPAR_FABRIC_AXIDMA_0_S2MM_INTROUT_VEC_ID
#define TX_INTR_ID              XPAR_FABRIC_AXIDMA_0_MM2S_INTROUT_VEC_ID
#define INTC_DEVICE_ID          XPAR_SCUGIC_SINGLE_DEVICE_ID
#define DDR_BASE_ADDR           XPAR_PS7_DDR_0_S_AXI_BASEADDR  //0x00100000
#define MEM_BASE_ADDR           (DDR_BASE_ADDR + 0x1000000)    //0x01100000
#define TX_BUFFER_BASE          (MEM_BASE_ADDR + 0x00100000)   //0x01200000
#define RX_BUFFER_BASE          (MEM_BASE_ADDR + 0x00300000)   //0x01400000
#define RESET_TIMEOUT_COUNTER   10000                          //复位时间
#define TEST_START_VALUE        0x0                            //测试起始值
#define MAX_PKT_LEN             0x100                          //发送包长度

/************************** Function Prototypes ******************************/

static int check_data(int length, u8 start_value);
static void tx_intr_handler(void *callback);
static void rx_intr_handler(void *callback);
static int setup_intr_system(XScuGic *int_ins_ptr, XAxiDma *axidma_ptr,
                            u16 tx_intr_id, u16 rx_intr_id);
static void disable_intr_system(XScuGic *int_ins_ptr, u16 tx_intr_id,
                               u16 rx_intr_id);

/************************** Variable Definitions *****************************/

static XAxiDma axidma;          //XAxiDma实例
static XScuGic intc;            //中断控制器的实例
volatile int tx_done;           //发送完成标志
volatile int rx_done;           //接收完成标志
volatile int error;             //传输出错标志

/************************** Function Definitions *****************************/

int main(void)
{
    int i;
    int status;
    u8 value;
    u8 *tx_buffer_ptr;
    u8 *rx_buffer_ptr;
    XAxiDma_Config *config;
    
    tx_buffer_ptr = (u8 *)TX_BUFFER_BASE;
    rx_buffer_ptr = (u8 *)RX_BUFFER_BASE;
    
    xil_printf("\r\n--- Entering main() --- \r\n");
    
    config = XAxiDma_LookupConfig(DMA_DEV_ID);
    if (!config) {
        xil_printf("No config found for %d\r\n", DMA_DEV_ID);
        return XST_FAILURE;
    }
    
    //初始化DMA引擎
    status = XAxiDma_CfgInitialize(&axidma, config);
    if (status != XST_SUCCESS) {
        xil_printf("Initialization failed %d\r\n", status);
        return XST_FAILURE;
    }
    
    if (XAxiDma_HasSg(&axidma)) {
        xil_printf("Device configured as SG mode \r\n");
        return XST_FAILURE;
    }
    
    //建立中断系统
    status = setup_intr_system(&intc, &axidma, TX_INTR_ID, RX_INTR_ID);
    if (status != XST_SUCCESS) {
        xil_printf("Failed intr setup\r\n");
        return XST_FAILURE;
    }
    
    //初始化标志信号
    tx_done = 0;
    rx_done = 0;
    error = 0;
    
    value = TEST_START_VALUE;
    for (i = 0; i < MAX_PKT_LEN; i++) {
        tx_buffer_ptr[i] = value;
        value = (value + 1) & 0xFF;
    }
    
    Xil_DCacheFlushRange((UINTPTR)tx_buffer_ptr, MAX_PKT_LEN); //刷新Data Cache
    
    status = XAxiDma_SimpleTransfer(&axidma, (UINTPTR)tx_buffer_ptr,
                                   MAX_PKT_LEN, XAXIDMA_DMA_TO_DEVICE);
    if (status != XST_SUCCESS) {
        return XST_FAILURE;
    }
    
    while (!tx_done && !error) //等待AXI DMA搬运完从DDR3到AXI Stream Data FIFO的数据
        ;
    //如果PS向FIFO传输出错
    if (error) {
        xil_printf("Failed test transmit%s done\r\n", tx_done ? "" : " not");
        goto Done;
    }
    
    status = XAxiDma_SimpleTransfer(&axidma, (UINTPTR)rx_buffer_ptr,
                                   MAX_PKT_LEN, XAXIDMA_DEVICE_TO_DMA);
    if (status != XST_SUCCESS) {
        return XST_FAILURE;
    }
    
    while (!rx_done && !error) //等待AXI DMA搬运完从AXI Stream Data FIFO到DDR3的数据
        ;
    // 如果PS接收FIFO传过来的数据出错
    if (error) {
        xil_printf("Failed test receive%s done\r\n", rx_done ? "" : " not");
        goto Done;
    }
    
    Xil_DCacheFlushRange((UINTPTR)rx_buffer_ptr, MAX_PKT_LEN); //刷新Data Cache
    //传输完成，检查数据是否正确
    status = check_data(MAX_PKT_LEN, TEST_START_VALUE);
    if (status != XST_SUCCESS) {
        xil_printf("Data check failed\r\n");
        goto Done;
    }
    
    xil_printf("Successfully ran AXI DMA Loop\r\n");
    disable_intr_system(&intc, TX_INTR_ID, RX_INTR_ID);
    
Done:
    xil_printf("--- Exiting main() --- \r\n");
    return XST_SUCCESS;
}
