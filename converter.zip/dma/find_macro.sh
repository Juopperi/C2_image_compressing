#!/bin/bash

# 检查参数
if [ $# -lt 2 ]; then
    echo "用法: $0 <文件夹路径> <宏名称> [文件扩展名(可选)]"
    echo "例如: $0 /path/to/search XPAR_AXIDMA_0_DEVICE_ID .h"
    exit 1
fi

SEARCH_DIR="$1"
MACRO_NAME="$2"
FILE_EXT="${3:-.}"  # 默认搜索所有文件，如果提供了扩展名则只搜索该类型文件

echo "在 $SEARCH_DIR 中搜索宏 $MACRO_NAME ..."

# 使用grep搜索指定宏定义
# -r: 递归搜索
# -l: 只显示文件名
# -i: 忽略大小写
# --include: 只搜索特定扩展名的文件
# 单引号防止宏名被shell展开

if [ "$FILE_EXT" = "." ]; then
    grep -r -l --include="*" "$MACRO_NAME" "$SEARCH_DIR"
else
    grep -r -l --include="*$FILE_EXT" "$MACRO_NAME" "$SEARCH_DIR"
fi

# 检查搜索结果
if [ $? -ne 0 ]; then
    echo "未找到包含宏 $MACRO_NAME 的文件"
    exit 1
fi
